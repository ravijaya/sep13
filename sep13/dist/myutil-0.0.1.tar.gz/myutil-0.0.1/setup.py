from distutils.core import setup

setup(
    name='myutil',
    version='0.0.1',
    packages=['myutils'],
    author='jaya',
    description='a sample python packages'
)
